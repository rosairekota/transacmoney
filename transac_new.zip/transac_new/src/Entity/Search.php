<?php
namespace App\Entity;

/**
 * This class help to search all data
 */
class Search
{   
    /**
     * @var string|null
     */
    public $code_secret;
}
